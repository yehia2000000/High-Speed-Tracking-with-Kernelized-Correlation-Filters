# KCF: one flow function, a qemu tracker and a gem5 benchmark

Second round on top of `kcf_repo_changes.zip`. The kernels now run from one function,
`ref::kcf_flow`, and each simulator has its own file.

## Apply (from the repo root)

```bash
unzip -o kcf_flow_changes.zip -x KCF_FLOW_CHANGES.md kcf_flow.patch
rm -f example/source/kcf_app.cpp example/source/kcf_scalar.cpp \
      example/include/kcf_prof.hpp example/include/kcf_scalar.hpp
rmdir example/include 2>/dev/null
cmake -S . -B build        # re-run configure: the targets come from file globs
```

`kcf_flow.patch` is the same change as a diff, for review.

## What changed

| File | Change |
| --- | --- |
| `test/reference/include/KCF_flow.hpp` (new) | `ref::KcfParams`, `ref::KCF_DEFAULT_PARAMS`, `ref::KcfBox`, `ref::KcfState` (all buffers, plain struct, about 1 MB), `ref::KcfFlowStats`, and the three functions below |
| `test/reference/source/KCF_flow.cpp` (new) | `kcf_setup` (Hann, labels, model pointers), `kcf_flow_init` (frame 1: features + first train), `kcf_flow` (one frame: detect at the old centre → K6 → move the box → train at the new centre). Kernels only, no I/O. With a `KcfFlowStats*` each stage is timed with `Timer`, like a kernel in `Add_benchmark`; with `nullptr` it is just the calls |
| `benchmark/source/KCF_benchmark.cpp` (new) | gem5 (and qemu as a quick check). Frames from `images/kcf_seq.hpp`. Frame 1 trains (not timed), every next frame runs `ref::kcf_flow` under a `Timer`. Prints cycles/instructions per frame, per kernel and in total; `Output is correct.` when every timed frame is within 20 px of the ground truth |
| `example/source/kcf_tracker.cpp` (new) | qemu-user only. Whole PGM sequence, box and error per frame, `output_scalar.txt`, precision@20px, `Example passed.` No timing |
| `example/CMakeLists.txt` | back to the plain one-image-pair-per-source loop, plus `EXAMPLE_QEMU_ONLY` (kcf_tracker is not built for gem5) and `KCF_SEQ_DIR` |
| `benchmark/CMakeLists.txt` | qemu benchmarks also see `images/` (for `kcf_seq.hpp`); gem5 already did through lib |
| `example/source/kcf_app.cpp`, `example/source/kcf_scalar.cpp`, `example/include/kcf_scalar.hpp`, `example/include/kcf_prof.hpp` | removed: the tracker class, the PROF macros and the two-platform app are replaced by the three files above. `KCF_PROFILE` is gone |
| `scripts/kcf_sequence.py`, `images/kcf_seq.hpp` | comments point to the new files (no pixel change) |
| `README.md` | the KCF section rewritten |

## Targets

| Target | Runs | Output |
| --- | --- | --- |
| `run_kcf_tracker_qemu` | all frames of `images/kcf_seq_pgm` (or `-DKCF_SEQ_DIR`) | `build/example/kcf_tracker_qemu.log`, `images/kcf_seq_pgm/output_scalar.txt` |
| `run_KCF_benchmark_gem5` | `images/kcf_seq.hpp` (3 frames: 1 init + 2 timed) | `build/benchmark/KCF_benchmark_gem5.log`, `build/benchmark/KCF_benchmark_gem5-m5out/` |
| `run_KCF_benchmark_qemu` | same as gem5, functional check | `build/benchmark/KCF_benchmark_qemu.log` (counters are host ticks) |

gem5 needs `-DGEM5_EXTRA_ARGS="--disable-difftest;--maxinsts=2000000000"`: frame 1 plus two flows
are about 78 M instructions and XS-GEM5 stops at 40 M by default.

## Checked here (gem5 itself is not available here)

- `kcf_tracker_qemu` on all 471 frames of David: `output_scalar.txt` byte-identical to the old
  `kcf_app_qemu` (precision 100 %, mean centre error 8.65 px).
- `KCF_benchmark_qemu`: `Output is correct.` (frames 2 and 3 at 2.41 and 3.43 px).
- One `ref::kcf_flow` = 30.99 M instructions, counted one by one under qemu (`-d in_asm,exec`).
- `KCF_benchmark_gem5` links against nexus-am: no undefined symbols, no `.init_array`,
  `g_state` (977,696 B) in `.bss`, `KCF_benchmark.bin` 1.24 MB.
- ctest: all 10 qemu tests pass. `unit_tests_gem5/qemu` still fail to link, as before:
  `K1_test.cpp`, `K2_test.cpp` and `K5_test.cpp` are copies of `Add_test.cpp`.
